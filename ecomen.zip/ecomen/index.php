<?php include( 'includes/header.php'); ?>
    <h1>Hello, world!</h1>
<?php include('includes/footer.php'); ?>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    