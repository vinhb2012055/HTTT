// admin/assets/js/main.js

$(document).ready(function() {
    // Submit form to add new member
    $('#addMemberForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        $.ajax({
            url: 'functions/add_member.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                alert(response);
                if (response.trim() === 'success') {
                    $('#addMemberModal').modal('hide');
                    location.reload();
                } else {
                    alert('Failed to add member. Please try again later.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to add member. Please try again later.');
            }
        });
    });

    // View member details
    $(".view-btn").click(function() {
        var nv_ma = $(this).data('id');
        $.ajax({
            url: 'functions/get_member.php',
            type: 'POST',
            data: { nv_ma: nv_ma },
            success: function(response) {
                var member = JSON.parse(response);
                $("#view_nv_ten").val(member.nv_ten);
                $("#view_nv_diachi").val(member.nv_diachi);
                $("#view_nv_sdt").val(member.nv_sdt);
                $("#view_nv_role").val(member.nv_role);
                $('#viewMemberModal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to fetch member details. Please try again later.');
            }
        });
    });

    // Edit member details
    $(".edit-btn").click(function() {
        var nv_ma = $(this).data('id');
        $.ajax({
            url: 'functions/get_member.php',
            type: 'POST',
            data: { nv_ma: nv_ma },
            success: function(response) {
                var member = JSON.parse(response);
                $("#edit_nv_ma").val(member.nv_ma);
                $("#edit_nv_ten").val(member.nv_ten);
                $("#edit_nv_diachi").val(member.nv_diachi);
                $("#edit_nv_sdt").val(member.nv_sdt);
                $("#edit_nv_role").val(member.nv_role);
                $('#editMemberModal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to fetch member details. Please try again later.');
            }
        });
    });

    // Submit form to edit member
    $('#editMemberForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        $.ajax({
            url: 'functions/update_member.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                alert(response);
                if (response.trim() === 'success') {
                    $('#editMemberModal').modal('hide');
                    location.reload();
                } else {
                    alert('Failed to update member. Please try again later.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to update member. Please try again later.');
            }
        });
    });

    // Delete member
    $(".delete-btn").click(function() {
        var nv_ma = $(this).data('id');
        $.ajax({
            url: 'functions/update_status.php',
            type: 'POST',
            data: { nv_ma: nv_ma },
            success: function(response) {
                alert(response);
                if (response.trim() === 'Status updated successfully') {
                    location.reload();
                } else {
                    alert('Failed to update status. Please try again later.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to update status. Please try again later.');
            }
        });
    });
});
$(document).ready(function() {
    // Handle province change
    $('#t_ma').change(function() {
        var t_ma = $(this).val();
        if (t_ma) {
            $.ajax({
                url: 'functions/get_districts.php',
                type: 'POST',
                data: { t_ma: t_ma },
                success: function(response) {
                    $('#h_ma').html(response);
                    $('#x_ma').html('<option value="">Select Commune</option>');
                    $('#tdg_ma').html('<option value="">Select Street</option>');
                }
            });
        } else {
            $('#h_ma').html('<option value="">Select District</option>');
            $('#x_ma').html('<option value="">Select Commune</option>');
            $('#tdg_ma').html('<option value="">Select Street</option>');
        }
    });

    // Handle district change
    $('#h_ma').change(function() {
        var h_ma = $(this).val();
        if (h_ma) {
            $.ajax({
                url: 'functions/get_communes.php',
                type: 'POST',
                data: { h_ma: h_ma },
                success: function(response) {
                    $('#x_ma').html(response);
                    $('#tdg_ma').html('<option value="">Select Street</option>');
                }
            });
        } else {
            $('#x_ma').html('<option value="">Select Commune</option>');
            $('#tdg_ma').html('<option value="">Select Street</option>');
        }
    });

    // Handle commune change
    $('#x_ma').change(function() {
        var x_ma = $(this).val();
        if (x_ma) {
            $.ajax({
                url: 'functions/get_streets.php',
                type: 'POST',
                data: { x_ma: x_ma },
                success: function(response) {
                    $('#tdg_ma').html(response);
                }
            });
        } else {
            $('#tdg_ma').html('<option value="">Select Street</option>');
        }
    });

    // Submit form to add new user
    $('#addUserForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        $.ajax({
            url: 'functions/add_user.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                alert(response);
                if (response.trim() === 'success') {
                    $('#addUserModal').modal('hide');
                    location.reload();
                } else {
                    alert('Failed to add user. Please try again later.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to add user. Please try again later.');
            }
        });
        
    });
});

