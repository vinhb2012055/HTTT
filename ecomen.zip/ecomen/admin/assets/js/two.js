$(document).ready(function() {
    // Submit form to add new user
    $('#addUserForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        $.ajax({
            url: 'functions/add_user.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                alert(response);
                if (response.trim() === 'success') {
                    $('#addUserModal').modal('hide');
                    location.reload();
                } else {
                    alert('Failed to add user. Please try again later.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to add user. Please try again later.');
            }
        });
    });

    // View user details
    $(document).on('click', '.view-btn', function() {
        var nd_ma = $(this).data('id');
        $.ajax({
            url: 'functions/get_user.php',
            type: 'POST',
            data: { nd_ma: nd_ma },
            success: function(response) {
                var user = JSON.parse(response);
                $("#view_nd_ten").val(user.nd_ten);
                $("#view_nd_sdt").val(user.nd_sdt);
                $("#view_nd_diachi").val(user.nd_diachi);
                $("#view_nd_lnd_ma").val(user.lnd_ma);
                $('#viewUserModal').modal('show');
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to fetch user details. Please try again later.');
            }
        });
    });

    $(document).on('click', '.edit-btn', function() {
        var nd_ma = $(this).data('id');
        $.ajax({
            url: 'functions/get_user.php',
            type: 'POST',
            data: { nd_ma: nd_ma },
            success: function(response) {
                var user = JSON.parse(response);
                $("#edit_nd_ma").val(user.nd_ma);
                $("#edit_nd_ten").val(user.nd_ten);
                $("#edit_nd_sdt").val(user.nd_sdt);
                $("#edit_nd_diachi").val(user.nd_diachi);
                $("#edit_lnd_ma").val(user.lnd_ma);
    
                // Fetch streets
                fetchStreets(function(options) {
                    $("#edit_tdg_ma").html(options).val(user.tdg_ma);
                    $('#editUserModal').modal('show');
                });
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to fetch user details. Please try again later.');
            }
        });
    });
    
    function fetchStreets(callback) {
        $.ajax({
            url: 'functions/get_streets.php',
            type: 'GET',
            success: function(response) {
                var streets = JSON.parse(response);
                var options = '<option value="">Select Street</option>';
                streets.forEach(function(street) {
                    options += '<option value="' + street.tdg_ma + '">' + street.tdg_ten + '</option>';
                });
                callback(options);
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
            }
        });
    }
    

    // Submit form to edit user
    $('#editUserForm').submit(function(e) {
        e.preventDefault();
        var formData = $(this).serialize();
        $.ajax({
            url: 'functions/update_user.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                alert(response);
                if (response.trim() === 'success') {
                    $('#editUserModal').modal('hide');
                    location.reload();
                } else {
                    alert('Failed to update user. Please try again later.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to update user. Please try again later.');
            }
        });
    });
    

    // Delete user
    $(document).on('click', '.delete-btn', function() {
        var nd_ma = $(this).data('id');
        $.ajax({
            url: 'functions/update_user_status.php',
            type: 'POST',
            data: { nd_ma: nd_ma },
            success: function(response) {
                alert(response);
                if (response.trim() === 'Status updated successfully') {
                    location.reload();
                } else {
                    alert('Failed to update status. Please try again later.');
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
                alert('Failed to update status. Please try again later.');
            }
        });
    });

    // Load districts based on selected province
    $('#t_ma').change(function() {
        var t_ma = $(this).val();
        if (t_ma) {
            $.ajax({
                url: 'functions/get_districts.php',
                type: 'POST',
                data: { t_ma: t_ma },
                success: function(response) {
                    $('#h_ma').html(response);
                    $('#x_ma').html('<option value="">Select Commune</option>');
                    $('#tdg_ma').html('<option value="">Select Street</option>');
                },
                error: function(xhr, status, error) {
                    console.error(xhr.status);
                    console.error(error);
                }
            });
        } else {
            $('#h_ma').html('<option value="">Select District</option>');
            $('#x_ma').html('<option value="">Select Commune</option>');
            $('#tdg_ma').html('<option value="">Select Street</option>');
        }
    });

    // Load communes based on selected district
    $('#h_ma').change(function() {
        var h_ma = $(this).val();
        if (h_ma) {
            $.ajax({
                url: 'functions/get_communes.php',
                type: 'POST',
                data: { h_ma: h_ma },
                success: function(response) {
                    $('#x_ma').html(response);
                    $('#tdg_ma').html('<option value="">Select Street</option>');
                },
                error: function(xhr, status, error) {
                    console.error(xhr.status);
                    console.error(error);
                }
            });
        } else {
            $('#x_ma').html('<option value="">Select Commune</option>');
            $('#tdg_ma').html('<option value="">Select Street</option>');
        }
    });

    // Load streets
    $('#tdg_ma').ready(function() {
        $.ajax({
            url: 'functions/get_streets.php',
            type: 'GET',
            success: function(response) {
                $('#tdg_ma').html(response);
            },
            error: function(xhr, status, error) {
                console.error(xhr.status);
                console.error(error);
            }
        });
    });
});
