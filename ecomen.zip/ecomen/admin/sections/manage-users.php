<?php include_once('../../config/connection.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- Adjust the path to your custom CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <!-- Button to trigger modal -->
        <button type="button" class="btn btn-outline-success mb-3" data-toggle="modal" data-target="#addUserModal">Add User</button>
        
        <!-- Modal for Adding User -->
        <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addUserModalLabel">Add User</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Form to add new user -->
                        <form id="addUserForm">
                            <div class="form-group">
                                <label for="nd_ten">Name</label>
                                <input type="text" class="form-control" id="nd_ten" name="nd_ten" required>
                            </div>
                            <div class="form-group">
                                <label for="nd_sdt">Phone</label>
                                <input type="text" class="form-control" id="nd_sdt" name="nd_sdt">
                            </div>
                            <div class="form-group">
                                <label for="t_ma">Province</label>
                                <select class="form-control" id="t_ma" name="t_ma">
                                    <option value="">Select Province</option>
                                    <?php
                                    $sql_province = "SELECT * FROM tinh";
                                    $result_province = $conn->query($sql_province);
                                    if ($result_province->num_rows > 0) {
                                        while ($row_province = $result_province->fetch_assoc()) {
                                            echo '<option value="' . $row_province['t_ma'] . '">' . $row_province['t_ten'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="h_ma">District</label>
                                <select class="form-control" id="h_ma" name="h_ma">
                                    <option value="">Select District</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="x_ma">Commune</label>
                                <select class="form-control" id="x_ma" name="x_ma">
                                    <option value="">Select Commune</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="tdg_ma">Street</label>
                                <select class="form-control" id="tdg_ma" name="tdg_ma">
                                    <option value="">Select Street</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="nd_diachi">Address</label>
                                <input type="text" class="form-control" id="nd_diachi" name="nd_diachi">
                            </div>
                            <div class="form-group">
                                <label for="lnd_ma">User Type</label>
                                <select class="form-control" id="lnd_ma" name="lnd_ma">
                                    <?php
                                    $sql_user_type = "SELECT * FROM loainguoidung";
                                    $result_user_type = $conn->query($sql_user_type);
                                    if ($result_user_type->num_rows > 0) {
                                        while ($row_user_type = $result_user_type->fetch_assoc()) {
                                            echo '<option value="' . $row_user_type['lnd_ma'] . '">' . $row_user_type['lnd_ten'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
         <!-- Modal for Viewing User -->
        <div class="modal fade" id="viewUserModal" tabindex="-1" aria-labelledby="viewUserModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="viewUserModalLabel">View User</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="viewUserForm">
                            <div class="form-group">
                                <label for="view_nd_ten">Name</label>
                                <input type="text" class="form-control" id="view_nd_ten" name="nd_ten" disabled>
                            </div>
                            <div class="form-group">
                                <label for="view_nd_sdt">Phone</label>
                                <input type="text" class="form-control" id="view_nd_sdt" name="nd_sdt" disabled>
                            </div>
                            <div class="form-group">
                                <label for="view_nd_diachi">Address</label>
                                <input type="text" class="form-control" id="view_nd_diachi" name="nd_diachi" disabled>
                            </div>
                            <div class="form-group">
                                <label for="view_nd_lnd_ma">User Type</label>
                                <select class="form-control" id="view_nd_lnd_ma" name="lnd_ma" disabled>
                                    <?php
                                    $sql_user_type = "SELECT * FROM loainguoidung";
                                    $result_user_type = $conn->query($sql_user_type);
                                    if ($result_user_type->num_rows > 0) {
                                        while ($row_user_type = $result_user_type->fetch_assoc()) {
                                            echo '<option value="' . $row_user_type['lnd_ma'] . '">' . $row_user_type['lnd_ten'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
     <!-- Modal for Editing User -->
     <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                    </div>
                    <div class="modal-body">
                        <form id="editUserForm">
                            <input type="hidden" id="edit_nd_ma" name="nd_ma">
                            <div class="form-group">
                                <label for="edit_nd_ten">Name</label>
                                <input type="text" class="form-control" id="edit_nd_ten" name="nd_ten" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_nd_sdt">Phone</label>
                                <input type="text" class="form-control" id="edit_nd_sdt" name="nd_sdt">
                            </div>
                            <div class="form-group">
                                <label for="edit_nd_diachi">Address</label>
                                <input type="text" class="form-control" id="edit_nd_diachi" name="nd_diachi">
                            </div>
                            <div class="form-group">
                                <label for="edit_lnd_ma">User Type</label>
                                <select class="form-control" id="edit_lnd_ma" name="lnd_ma">
                                    <?php
                                        $sql_user_type = "SELECT * FROM loainguoidung";
                                        $result_user_type = $conn->query($sql_user_type);
                                        if ($result_user_type->num_rows > 0) {
                                            while ($row_user_type = $result_user_type->fetch_assoc()) {
                                                echo '<option value="' . $row_user_type['lnd_ma'] . '">' . $row_user_type['lnd_ten'] . '</option>';
                                            }
                                        }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="edit_tdg_ma">Street</label>
                                <select class="form-control" id="edit_tdg_ma" name="tdg_ma">
                                    <option value="">Select Street</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
                  
        <!-- Manage Users Section -->
        <div class="card">
            <div class="card-header">
                <h3>Manage Users</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>User Code</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>User Type</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT n.*, l.lnd_ten AS user_type_name FROM nguoidung n INNER JOIN loainguoidung l ON n.lnd_ma = l.lnd_ma WHERE n.nd_trangthai = 0";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    ?>
                                    <tr>
                                        <td><?php echo $row['nd_ma']; ?></td>
                                        <td><?php echo $row['nd_ten']; ?></td>
                                        <td><?php echo $row['nd_sdt']; ?></td>
                                        <td><?php echo $row['nd_diachi']; ?></td>
                                        <td><?php echo $row['user_type_name']; ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-info view-btn" data-id="<?php echo $row['nd_ma']; ?>">View</button>
                                            <button class="btn btn-sm btn-warning edit-btn" data-id="<?php echo $row['nd_ma']; ?>">Edit</button>
                                            <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo $row['nd_ma']; ?>">Delete</button>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="6" class="text-center">No users found.</td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="assets/js/two.js"></script>
</body>
</html>
