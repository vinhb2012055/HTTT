<?php include_once('../../config/connection.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Members</title>
    <link rel="stylesheet" href="assets/css/styles.css"> <!-- Adjust the path to your custom CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <!-- Button to trigger modal -->
        <button type="button" class="btn btn-outline-success mb-3" data-toggle="modal" data-target="#addMemberModal">Add Member</button>
        
        <!-- Modal for Adding Member -->
        <div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addMemberModalLabel">Add Member</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Form to add new member -->
                        <form id="addMemberForm">
                            <div class="form-group">
                                <label for="nv_ten">Name</label>
                                <input type="text" class="form-control" id="nv_ten" name="nv_ten" required>
                            </div>
                            <div class="form-group">
                                <label for="nv_diachi">Address</label>
                                <input type="text" class="form-control" id="nv_diachi" name="nv_diachi">
                            </div>
                            <div class="form-group">
                                <label for="nv_sdt">Phone</label>
                                <input type="text" class="form-control" id="nv_sdt" name="nv_sdt">
                            </div>
                            <div class="form-group">
                                <label for="nv_matkhau">Password</label>
                                <input type="password" class="form-control" id="nv_matkhau" name="nv_matkhau" required>
                            </div>
                            <div class="form-group">
                                <label for="nv_role">Role</label>
                                <select class="form-control" id="nv_role" name="nv_role">
                                    <?php
                                    $sql_role = "SELECT * FROM chitietnhanvien";
                                    $result_role = $conn->query($sql_role);
                                    if ($result_role->num_rows > 0) {
                                        while ($row_role = $result_role->fetch_assoc()) {
                                            echo '<option value="' . $row_role['nv_role'] . '">' . $row_role['nv_ten'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Add</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal for Viewing Member -->
        <div class="modal fade" id="viewMemberModal" tabindex="-1" aria-labelledby="viewMemberModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="viewMemberModalLabel">View Member</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Form to view member details (inputs disabled) -->
                        <form id="viewMemberForm">
                            <div class="form-group">
                                <label for="view_nv_ten">Name</label>
                                <input type="text" class="form-control" id="view_nv_ten" name="nv_ten" disabled>
                            </div>
                            <div class="form-group">
                                <label for="view_nv_diachi">Address</label>
                                <input type="text" class="form-control" id="view_nv_diachi" name="nv_diachi" disabled>
                            </div>
                            <div class="form-group">
                                <label for="view_nv_sdt">Phone</label>
                                <input type="text" class="form-control" id="view_nv_sdt" name="nv_sdt" disabled>
                            </div>
                            <div class="form-group">
                                <label for="view_nv_role">Role</label>
                                <select class="form-control" id="view_nv_role" name="nv_role" disabled>
                                    <?php
                                    $sql_role = "SELECT * FROM chitietnhanvien";
                                    $result_role = $conn->query($sql_role);
                                    if ($result_role->num_rows > 0) {
                                        while ($row_role = $result_role->fetch_assoc()) {
                                            echo '<option value="' . $row_role['nv_role'] . '">' . $row_role['nv_ten'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal for Editing Member -->
        <div class="modal fade" id="editMemberModal" tabindex="-1" aria-labelledby="editMemberModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editMemberModalLabel">Edit Member</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <!-- Form to edit member details -->
                        <form id="editMemberForm">
                            <input type="hidden" id="edit_nv_ma" name="nv_ma">
                            <div class="form-group">
                                <label for="edit_nv_ten">Name</label>
                                <input type="text" class="form-control" id="edit_nv_ten" name="nv_ten" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_nv_diachi">Address</label>
                                <input type="text" class="form-control" id="edit_nv_diachi" name="nv_diachi">
                            </div>
                            <div class="form-group">
                                <label for="edit_nv_sdt">Phone</label>
                                <input type="text" class="form-control" id="edit_nv_sdt" name="nv_sdt">
                            </div>
                            <div class="form-group">
                                <label for="edit_nv_role">Role</label>
                                <select class="form-control" id="edit_nv_role" name="nv_role">
                                    <?php
                                    $sql_role = "SELECT * FROM chitietnhanvien";
                                    $result_role = $conn->query($sql_role);
                                    if ($result_role->num_rows > 0) {
                                        while ($row_role = $result_role->fetch_assoc()) {
                                            echo '<option value="' . $row_role['nv_role'] . '">' . $row_role['nv_ten'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Manage Members Section -->
        <div class="card">
            <div class="card-header">
                <h3>Manage Members</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Employee Code</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Phone</th>
                                <th>Role</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sql = "SELECT n.*, c.nv_ten AS nv_role_name FROM nhanvien n INNER JOIN chitietnhanvien c ON n.nv_role = c.nv_role WHERE n.nv_trangthai = 0";
                            $result = $conn->query($sql);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    ?>
                                    <tr>
                                        <td><?php echo $row['nv_ma']; ?></td>
                                        <td><?php echo $row['nv_ten']; ?></td>
                                        <td><?php echo $row['nv_diachi']; ?></td>
                                        <td><?php echo $row['nv_sdt']; ?></td>
                                        <td><?php echo $row['nv_role_name']; ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-info view-btn" data-id="<?php echo $row['nv_ma']; ?>">View</button>
                                            <button class="btn btn-sm btn-warning edit-btn" data-id="<?php echo $row['nv_ma']; ?>">Edit</button>
                                            <button class="btn btn-sm btn-danger delete-btn" data-id="<?php echo $row['nv_ma']; ?>">Delete</button>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="6" class="text-center">No members found.</td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>
</html>
