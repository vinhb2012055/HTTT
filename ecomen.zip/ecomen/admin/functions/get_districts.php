<?php
include('../../config/connection.php');

if (isset($_POST['t_ma'])) {
    $t_ma = $_POST['t_ma'];
    $sql_district = "SELECT * FROM huyen WHERE t_ma = '$t_ma'";
    $result_district = $conn->query($sql_district);
    echo '<option value="">Select District</option>';
    if ($result_district->num_rows > 0) {
        while ($row_district = $result_district->fetch_assoc()) {
            echo '<option value="' . $row_district['h_ma'] . '">' . $row_district['h_ten'] . '</option>';
        }
    }
}
?>
