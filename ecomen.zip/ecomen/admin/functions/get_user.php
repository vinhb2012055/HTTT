<?php
include('../../config/connection.php');

if (isset($_POST['nd_ma'])) {
    $nd_ma = $_POST['nd_ma'];
    $sql = "SELECT * FROM nguoidung WHERE nd_ma = '$nd_ma'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo json_encode($user);
    } else {
        echo json_encode(['error' => 'User not found']);
    }
}
?>
