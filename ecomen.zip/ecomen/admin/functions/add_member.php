<?php
session_start();
include('../../config/connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Nhận dữ liệu từ biểu mẫu
    $nv_ten = $_POST['nv_ten'];
    $nv_diachi = $_POST['nv_diachi'];
    $nv_sdt = $_POST['nv_sdt'];
    $nv_matkhau = $_POST['nv_matkhau'];
    $nv_role = $_POST['nv_role'];

    // Hash mật khẩu sử dụng MD5
    $nv_matkhau = md5($nv_matkhau);

    // Validate name: no special characters
    if (!preg_match("/^[a-zA-Z ]*$/", $nv_ten)) {
        echo "Invalid name: Only letters and white space allowed.";
        exit;
    }

    // Lấy số từ mã nhân viên hiện tại
    $sql_max = "SELECT SUBSTRING(nv_ma, 9) AS num_part FROM nhanvien WHERE SUBSTRING(nv_ma, 1, 6) = 'NV0240' ORDER BY num_part DESC LIMIT 1";
    $result_max = $conn->query($sql_max);
    $row_max = $result_max->fetch_assoc();
    if ($row_max) {
        $next_num = (int)$row_max['num_part'] + 1;
    } else {
        $next_num = 1; // Nếu không có dữ liệu, bắt đầu từ 1
    }

    // Tạo mã nhân viên tự động
    $nv_ma = 'NV024' . sprintf('%06d', $next_num);

    // Thêm nhân viên vào cơ sở dữ liệu
    $sql = "INSERT INTO nhanvien (nv_ma, nv_ten, nv_diachi, nv_sdt, nv_matkhau, nv_role, nv_trangthai) VALUES ('$nv_ma', '$nv_ten', '$nv_diachi', '$nv_sdt', '$nv_matkhau', '$nv_role', 0)";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['nv_ma'] = $nv_ma;
        $_SESSION['nv_role'] = $nv_role;
        echo "success";
    } else {
        echo "error";
    }
}
?>
