<?php
include('../../config/connection.php');

if (isset($_POST['h_ma'])) {
    $h_ma = $_POST['h_ma'];
    $sql_commune = "SELECT * FROM xa WHERE h_ma = '$h_ma'";
    $result_commune = $conn->query($sql_commune);
    echo '<option value="">Select Commune</option>';
    if ($result_commune->num_rows > 0) {
        while ($row_commune = $result_commune->fetch_assoc()) {
            echo '<option value="' . $row_commune['x_ma'] . '">' . $row_commune['x_ten'] . '</option>';
        }
    }
}
?>
