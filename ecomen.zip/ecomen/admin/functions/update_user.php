<?php
include('../../config/connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Nhận dữ liệu từ biểu mẫu
    $nd_ma = $_POST['nd_ma'];
    $nd_ten = $_POST['nd_ten'];
    $nd_sdt = $_POST['nd_sdt'];
    $nd_diachi = $_POST['nd_diachi'];
    $lnd_ma = $_POST['lnd_ma'];
    $tdg_ma = isset($_POST['tdg_ma']) ? $_POST['tdg_ma'] : '';

    // Validate name: no special characters
    if (!preg_match("/^[a-zA-Z ]*$/", $nd_ten)) {
        echo "Invalid name: Only letters and white space allowed.";
        exit;
    }

    // Kiểm tra mã tuyến đường hợp lệ nếu có
    if (!empty($tdg_ma)) {
        $sql_check_street = "SELECT * FROM tuyenduong WHERE tdg_ma = '$tdg_ma'";
        $result_check_street = $conn->query($sql_check_street);
        if ($result_check_street->num_rows == 0) {
            echo "Error: The selected street (tdg_ma) does not exist.";
            exit;
        }
    }

    // Cập nhật người dùng vào cơ sở dữ liệu
    $sql = "UPDATE nguoidung SET nd_ten = '$nd_ten', nd_sdt = '$nd_sdt', nd_diachi = '$nd_diachi', lnd_ma = '$lnd_ma', tdg_ma = '$tdg_ma' WHERE nd_ma = '$nd_ma'";
    if ($conn->query($sql) === TRUE) {
        echo "success";
    } else {
        echo "error: " . $conn->error;
    }
}
?>
