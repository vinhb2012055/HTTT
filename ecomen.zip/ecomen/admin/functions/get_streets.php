<?php
include('../../config/connection.php');

$sql_street = "SELECT * FROM tuyenduong";
$result_street = $conn->query($sql_street);
$streets = array();

if ($result_street->num_rows > 0) {
    while ($row_street = $result_street->fetch_assoc()) {
        $streets[] = $row_street;
    }
}

echo json_encode($streets);
?>
