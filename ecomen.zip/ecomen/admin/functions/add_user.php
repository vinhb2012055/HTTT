<?php
session_start();
include('../../config/connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Nhận dữ liệu từ biểu mẫu
    $nd_ten = $_POST['nd_ten'];
    $nd_sdt = $_POST['nd_sdt'];
    $nd_diachi = $_POST['nd_diachi'];
    $lnd_ma = $_POST['lnd_ma'];
    $tdg_ma = $_POST['tdg_ma'];

    // Validate name: no special characters
    if (!preg_match("/^[a-zA-Z ]*$/", $nd_ten)) {
        echo "Invalid name: Only letters and white space allowed.";
        exit;
    }

    // Lấy số từ mã người dùng hiện tại
    $sql_max = "SELECT SUBSTRING(nd_ma, 7) AS num_part FROM nguoidung WHERE SUBSTRING(nd_ma, 1, 6) = 'ND0240' ORDER BY num_part DESC LIMIT 1";
    $result_max = $conn->query($sql_max);
    $row_max = $result_max->fetch_assoc();
    if ($row_max) {
        $next_num = (int)$row_max['num_part'] + 1;
    } else {
        $next_num = 2; // Nếu không có dữ liệu, bắt đầu từ 2
    }

    // Tạo mã người dùng tự động
    $nd_ma = 'ND024' . sprintf('%06d', $next_num);

    // Kiểm tra mã tuyến đường hợp lệ
    $sql_check_street = "SELECT * FROM tuyenduong WHERE tdg_ma = '$tdg_ma'";
    $result_check_street = $conn->query($sql_check_street);
    if ($result_check_street->num_rows == 0) {
        echo "Error: The selected street (tdg_ma) does not exist.";
        exit;
    }

    // Thêm người dùng vào cơ sở dữ liệu
    $sql = "INSERT INTO nguoidung (nd_ma, nd_ten, nd_sdt, nd_diachi, lnd_ma, tdg_ma, nd_trangthai) VALUES ('$nd_ma', '$nd_ten', '$nd_sdt', '$nd_diachi', '$lnd_ma', '$tdg_ma', 0)";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['nd_ma'] = $nd_ma;
        echo "success";
    } else {
        echo "error: " . $conn->error;
    }
}
?>
