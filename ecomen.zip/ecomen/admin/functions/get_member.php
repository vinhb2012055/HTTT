<?php
include('../../config/connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['nv_ma'])) {
        $nv_ma = $_POST['nv_ma'];

        $sql = "SELECT * FROM nhanvien WHERE nv_ma = '$nv_ma'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $member = $result->fetch_assoc();
            echo json_encode($member);
        } else {
            echo json_encode(['error' => 'Member not found']);
        }
    } else {
        echo json_encode(['error' => 'No employee code provided']);
    }
} else {
    echo json_encode(['error' => 'Method not allowed!']);
}
?>
