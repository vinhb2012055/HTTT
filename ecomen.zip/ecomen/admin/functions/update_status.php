<?php
include('../../config/connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['nv_ma'])) {
        $nv_ma = $_POST['nv_ma'];

        // Update nv_trangthai to 1 for the given nv_ma
        $update_sql = "UPDATE nhanvien SET nv_trangthai = 1 WHERE nv_ma = '$nv_ma'";
        if ($conn->query($update_sql) === TRUE) {
            echo "Status updated successfully";
        } else {
            echo "Error updating status: " . $conn->error;
        }
    } else {
        echo "No employee code provided";
    }
} else {
    echo "Method not allowed!";
}
?>
