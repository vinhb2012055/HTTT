<?php
include('../../config/connection.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nv_ma = $_POST['nv_ma'];
    $nv_ten = $_POST['nv_ten'];
    $nv_diachi = $_POST['nv_diachi'];
    $nv_sdt = $_POST['nv_sdt'];
    $nv_role = $_POST['nv_role'];

    // Validate name: no special characters
    if (!preg_match("/^[a-zA-Z ]*$/", $nv_ten)) {
        echo "Invalid name: Only letters and white space allowed.";
        exit;
    }

    $sql = "UPDATE nhanvien SET nv_ten = '$nv_ten', nv_diachi = '$nv_diachi', nv_sdt = '$nv_sdt', nv_role = '$nv_role' WHERE nv_ma = '$nv_ma'";
    if ($conn->query($sql) === TRUE) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
