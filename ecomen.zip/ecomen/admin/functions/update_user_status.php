<?php
include('../../config/connection.php');

if (isset($_POST['nd_ma'])) {
    $nd_ma = $_POST['nd_ma'];
    $sql = "UPDATE nguoidung SET nd_trangthai = 1 WHERE nd_ma = '$nd_ma'";
    if ($conn->query($sql) === TRUE) {
        echo "Status updated successfully";
    } else {
        echo "error: " . $conn->error;
    }
}
?>
