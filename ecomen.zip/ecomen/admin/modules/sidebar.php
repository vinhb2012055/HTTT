<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3" id="sidenav-main">
    <div class="sidenav-header">
        <i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
        <a class="navbar-brand m-0" href="javascript:void(0)">
            <img src="assets/img/logo-ct.png" class="navbar-brand-img h-100" style="filter: brightness(0%);" alt="main_logo">
            <span class="ms-1 font-weight-bold">Admin Dashboard</span>
        </a>
    </div>
    <hr class="horizontal dark mt-0">
    <div class="collapse navbar-collapse w-auto" id="sidenav-collapse-main">
        <ul class="navbar-nav">
            <li class="nav-item" style="background-color: BurlyWood;">
                <a class="nav-link" href="javascript:void(0)" data-section="dashboard">
                    <div class="icon icon-shape icon-sm bg-primary text-center border-radius-md">
                        <i class="ni ni-tv-2 text-white text-lg opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1" style="color:black">Dashboard</span>
                </a>
            </li>
           <li class="nav-item" style="background-color:BurlyWood;">
                <a class="nav-link"  href="javascript:void(0)" data-section="manage-members">
                    <div class="icon icon-shape icon-sm bg-success text-center border-radius-md">
                        <i class="ni ni-single-02 text-dark text-lg opacity-10" aria-hidden="true"></i>
                     </div>
                    <span class="nav-link-text ms-1" style="color:black;">Manage Members</span>
                </a>
            </li>
            <li class="nav-item" style="background-color:BurlyWood;">
                <a class="nav-link"  href="javascript:void(0)" data-section="manage-users">
                    <div class="icon icon-shape icon-sm bg-success text-center border-radius-md">
                        <i class="ni ni-single-02 text-dark text-lg opacity-10" aria-hidden="true"></i>
                     </div>
                    <span class="nav-link-text ms-1" style="color:black;">Manage Users</span>
                </a>
            </li>
            <li class="nav-item"style="background-color: BurlyWood;">
                <a class="nav-link" href="../logout.php">
                    <div class="icon icon-shape icon-sm bg-danger text-center border-radius-md">
                        <i class="ni ni-user-run text-white text-lg opacity-10" aria-hidden="true"></i>
                    </div>
                    <span class="nav-link-text ms-1" style="color:black">Logout</span>
                </a>
            </li>
        </ul>
    </div>
</aside>
