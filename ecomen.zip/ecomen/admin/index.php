<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="assets/img/favicon.png">
  <title>
    Material Dashboard 2 by Creative Tim
  </title>
  <!-- Fonts and icons -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900|Roboto+Slab:400,700" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <!-- Material Icons -->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <!-- CSS Files -->
  <link id="pagestyle" href="assets/css/material-dashboard.min.css" rel="stylesheet" />
</head>

<body class="g-sidenav-show  bg-gray-200">
    <?php include('modules/sidebar.php');?>
    <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
        <?php include('modules/navbar.php');?>
        <div id="content-section" class="container-fluid py-4">
            <?php include('sections/dashboard.php'); ?>
        </div>
        <?php include('modules/footer.php'); ?>
    </main>
    <script src="assets/js/main.js"></script>
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        function loadSection(section) {
            $('#content-section').load(`sections/${section}.php`);
        }

        $(document).ready(function() {
            // Load section from URL parameter if present
            const urlParams = new URLSearchParams(window.location.search);
            const section = urlParams.get('section') || 'dashboard';
            loadSection(section);

            // Handle dynamic section loading
            $('a[data-section]').on('click', function(e) {
                e.preventDefault();
                var section = $(this).data('section');
                loadSection(section);
                history.pushState(null, '', `index.php?section=${section}`);
            });
        });
    </script>
</body>
</html>
