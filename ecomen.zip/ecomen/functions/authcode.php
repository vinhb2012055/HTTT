<?php
session_start();
include('../config/connection.php'); // Include your database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nv_ma = $_POST['nv_ma'];
    $password = $_POST['password'];

    // Validate input: Employee code should not contain special characters
    if (!preg_match('/^[a-zA-Z0-9]*$/', $nv_ma)) {
        echo "error";
        exit;
    }

    // Hash the password using MD5
    $password = md5($password);

    // Check credentials in the database
    $query = "SELECT * FROM nhanvien WHERE nv_ma = '$nv_ma' AND nv_matkhau = '$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['nv_ma'] = $row['nv_ma'];
        $_SESSION['nv_role'] = $row['nv_role'];

        // Return success response
        echo "success";
    } else {
        echo "error";
    }
}
?>
