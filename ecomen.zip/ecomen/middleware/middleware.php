<?php
session_start();

function checkRole($requiredRole) {
    if (!isset($_SESSION['nv_role']) || $_SESSION['nv_role'] != $requiredRole) {
        header('Location: ../login.php');
        exit;
    }
}

function isLoggedIn() {
    return isset($_SESSION['nv_ma']);
}
?>
